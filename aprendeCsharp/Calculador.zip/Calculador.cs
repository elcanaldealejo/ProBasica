using System;

namespace aprendeCsharp
{
    class Calculador
    {
        static int Num1, Num2;

        static void Main()
        {
            
            var objetoVariables = new VariablesGlobales();


            Console.WriteLine("Escriba el Numero 1: ");
            Num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Escriba el Numero 2: ");
            Num2 = Convert.ToInt32(Console.ReadLine());

            objetoVariables.Suma(Num1,Num2);
            objetoVariables.Resta();
            
            objetoVariables.a = 4;
            objetoVariables.b = 5;
            Console.WriteLine("Producto -> {0}",objetoVariables.Producto());
        }
        
    }
}
